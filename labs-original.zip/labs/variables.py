"""
You have learned about managing Python types like strings and
numbers. Create a variable x that contains an integer 1, a variable y
that contains a string that contains the character "1", and a variable
z that contains a float value 1.0.

>>> x
1
>>> y
'1'
>>> z
1.0

Create a function that returns two arguments separated by a space.

>>> greeting('bob', 'smith')
'bob smith'
>>> greeting("hello", 1)
'hello 1'
>>> greeting(1, 5)
'1 5'


"""

# Add your code here



