"""
This is a test driven lab. Tests are the parts that look like Python
code entered in the interactive console.

>>> testing()
'Hello'

In order to run the tests execute:

$ python -m doctest getting_started.py

DO NOT EDIT THIS CODE!

Instead, add your own python code (including function definitions)
down below until all the tests pass.
"""

# Add your python code here!
