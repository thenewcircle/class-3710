"""
Provide a function called greeting that when passed an hour in military time 
prints the proper greeting.

>>> greeting(5)
Good morning, world!
>>> greeting(14)
Good afternoon, world!
>>> greeting(17)
Good evening, world!
>>> greeting(21)
Good night, world!
>>> greeting(0)
Good night, world!

"""

# add your code here

